-- Agni Gas Agency schema (SQLite). Safe to run repeatedly.
-- All money columns are *_paise INTEGER (see money.py).
-- When this moves to a server database, the table/column names stay the same.

CREATE TABLE IF NOT EXISTS counters (
    name  TEXT PRIMARY KEY,
    value INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS cylinder_types (
    id                    INTEGER PRIMARY KEY,
    name                  TEXT NOT NULL UNIQUE,
    kg                    REAL,
    sale_price_paise      INTEGER NOT NULL DEFAULT 0,
    wholesale_price_paise INTEGER NOT NULL DEFAULT 0,
    purchase_price_paise  INTEGER NOT NULL DEFAULT 0,
    security_paise        INTEGER NOT NULL DEFAULT 0,
    full_qty              INTEGER NOT NULL DEFAULT 0,
    empty_qty             INTEGER NOT NULL DEFAULT 0,
    damaged_qty           INTEGER NOT NULL DEFAULT 0,
    with_customers_qty    INTEGER NOT NULL DEFAULT 0,
    sort_order            INTEGER NOT NULL DEFAULT 0,
    active                INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS customers (
    id                     INTEGER PRIMARY KEY,
    name                   TEXT NOT NULL,
    phone                  TEXT,
    address                TEXT,
    type                   TEXT NOT NULL DEFAULT 'retail' CHECK (type IN ('retail', 'wholesale')),
    opening_balance_paise  INTEGER NOT NULL DEFAULT 0,
    note                   TEXT,
    active                 INTEGER NOT NULL DEFAULT 1,
    created_at             TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS suppliers (
    id                     INTEGER PRIMARY KEY,
    name                   TEXT NOT NULL,
    gstin                  TEXT NOT NULL,
    phone                  TEXT,
    address                TEXT,
    opening_balance_paise  INTEGER NOT NULL DEFAULT 0,
    note                   TEXT,
    active                 INTEGER NOT NULL DEFAULT 1,
    created_at             TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS sales (
    id              INTEGER PRIMARY KEY,
    number          TEXT NOT NULL UNIQUE,
    customer_id     INTEGER REFERENCES customers(id),
    sale_date       TEXT NOT NULL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    subtotal_paise  INTEGER NOT NULL DEFAULT 0,
    discount_paise  INTEGER NOT NULL DEFAULT 0,
    gst_percent     REAL    NOT NULL DEFAULT 0,
    gst_paise       INTEGER NOT NULL DEFAULT 0,
    total_paise     INTEGER NOT NULL DEFAULT 0,
    paid_paise      INTEGER NOT NULL DEFAULT 0,
    received_in     TEXT NOT NULL DEFAULT 'cash',
    status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled')),
    cancelled_at    TEXT,
    cancel_reason   TEXT,
    note            TEXT
);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id);

CREATE TABLE IF NOT EXISTS sale_items (
    id               INTEGER PRIMARY KEY,
    sale_id          INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    mode             TEXT NOT NULL DEFAULT 'refill',
    qty_out          INTEGER NOT NULL DEFAULT 0,
    qty_empty_in     INTEGER NOT NULL DEFAULT 0,
    rate_paise       INTEGER NOT NULL DEFAULT 0,
    amount_paise     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS payments (
    id            INTEGER PRIMARY KEY,
    number        TEXT NOT NULL UNIQUE,
    customer_id   INTEGER NOT NULL REFERENCES customers(id),
    amount_paise  INTEGER NOT NULL,
    payment_date  TEXT NOT NULL,
    received_in   TEXT NOT NULL DEFAULT 'cash',
    note          TEXT,
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled')),
    created_at    TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_customer ON payments(customer_id);

CREATE TABLE IF NOT EXISTS stock_movements (
    id               INTEGER PRIMARY KEY,
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    moved_at         TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    ref_type         TEXT,
    ref_id           INTEGER,
    full_delta       INTEGER NOT NULL DEFAULT 0,
    empty_delta      INTEGER NOT NULL DEFAULT 0,
    damaged_delta    INTEGER NOT NULL DEFAULT 0,
    note             TEXT
);

CREATE TABLE IF NOT EXISTS cylinder_ledger (
    id               INTEGER PRIMARY KEY,
    customer_id      INTEGER NOT NULL REFERENCES customers(id),
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    delta            INTEGER NOT NULL,
    ref_type         TEXT,
    ref_id           INTEGER,
    entry_date       TEXT NOT NULL,
    note             TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_cyl_ledger_customer ON cylinder_ledger(customer_id);

CREATE TABLE IF NOT EXISTS customer_prices (
    customer_id      INTEGER NOT NULL REFERENCES customers(id),
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    price_paise      INTEGER NOT NULL,
    PRIMARY KEY (customer_id, cylinder_type_id)
);

-- One supplier can supply many cylinder sizes; a size can have multiple suppliers.
-- The supplier-specific price is the default for new purchases from that supplier.
CREATE TABLE IF NOT EXISTS supplier_items (
    supplier_id          INTEGER NOT NULL REFERENCES suppliers(id),
    cylinder_type_id     INTEGER NOT NULL REFERENCES cylinder_types(id),
    purchase_price_paise INTEGER NOT NULL,
    PRIMARY KEY (supplier_id, cylinder_type_id)
);
CREATE INDEX IF NOT EXISTS idx_supplier_items_cylinder ON supplier_items(cylinder_type_id);

-- A purchase stores the supplier's invoice as a record. The original supplier bill
-- is optionally stored as a BLOB so it remains included in the normal DB backup.
-- This app does not issue a purchase bill to the supplier.
CREATE TABLE IF NOT EXISTS purchases (
    id                    INTEGER PRIMARY KEY,
    number                TEXT NOT NULL UNIQUE,
    supplier_id           INTEGER NOT NULL REFERENCES suppliers(id),
    purchase_date         TEXT NOT NULL,
    created_at            TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    subtotal_paise        INTEGER NOT NULL DEFAULT 0,
    gst_percent           REAL NOT NULL DEFAULT 0,
    gst_paise             INTEGER NOT NULL DEFAULT 0,
    total_paise           INTEGER NOT NULL DEFAULT 0,
    note                  TEXT,
    supplier_bill_name    TEXT,
    supplier_bill_mime    TEXT,
    supplier_bill_data    BLOB,
    status                TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled'))
);
CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(purchase_date);
CREATE INDEX IF NOT EXISTS idx_purchases_supplier ON purchases(supplier_id);

CREATE TABLE IF NOT EXISTS purchase_items (
    id                    INTEGER PRIMARY KEY,
    purchase_id           INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
    cylinder_type_id      INTEGER NOT NULL REFERENCES cylinder_types(id),
    full_in_qty           INTEGER NOT NULL DEFAULT 0,
    empty_out_qty         INTEGER NOT NULL DEFAULT 0,
    new_empty_qty         INTEGER NOT NULL DEFAULT 0,
    new_full_qty          INTEGER NOT NULL DEFAULT 0,
    rate_paise            INTEGER NOT NULL DEFAULT 0,
    security_rate_paise   INTEGER NOT NULL DEFAULT 0,
    amount_paise          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_purchase_items_purchase ON purchase_items(purchase_id);

-- Payments to suppliers are independent ledger entries. purchase_id is optional:
-- a payment can settle a particular purchase or be a general supplier payment/advance.
CREATE TABLE IF NOT EXISTS supplier_payments (
    id            INTEGER PRIMARY KEY,
    number        TEXT NOT NULL UNIQUE,
    supplier_id   INTEGER NOT NULL REFERENCES suppliers(id),
    purchase_id   INTEGER REFERENCES purchases(id),
    amount_paise  INTEGER NOT NULL,
    payment_date  TEXT NOT NULL,
    paid_from     TEXT NOT NULL DEFAULT 'cash' CHECK (paid_from IN ('cash', 'bank')),
    note          TEXT,
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled')),
    created_at    TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_supplier ON supplier_payments(supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_purchase ON supplier_payments(purchase_id);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_date ON supplier_payments(payment_date);


-- General stock items (accessories, stoves, regulators, hoses, etc.).
-- Cylinder types remain in cylinder_types because they have full/empty/damaged
-- stock states; catalog_items are ordinary quantity-based goods.
CREATE TABLE IF NOT EXISTS catalog_items (
    id                    INTEGER PRIMARY KEY,
    name                  TEXT NOT NULL COLLATE NOCASE UNIQUE,
    unit                  TEXT NOT NULL DEFAULT 'pcs',
    purchase_price_paise  INTEGER NOT NULL DEFAULT 0,
    sale_price_paise      INTEGER NOT NULL DEFAULT 0,
    wholesale_price_paise INTEGER NOT NULL DEFAULT 0,
    stock_qty_milli       INTEGER NOT NULL DEFAULT 0,
    active                INTEGER NOT NULL DEFAULT 1,
    created_at            TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_catalog_items_active_name ON catalog_items(active, name);

-- A supplier can offer many general items; the price is supplier-specific.
-- Deactivating an association does not delete the item or historical purchase rows.
CREATE TABLE IF NOT EXISTS supplier_catalog_items (
    supplier_id          INTEGER NOT NULL REFERENCES suppliers(id),
    item_id              INTEGER NOT NULL REFERENCES catalog_items(id),
    purchase_price_paise INTEGER NOT NULL,
    active               INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (supplier_id, item_id)
);
CREATE INDEX IF NOT EXISTS idx_supplier_catalog_items_item ON supplier_catalog_items(item_id);

-- Purchase line snapshots preserve the item name, unit and price as they were
-- on the supplier's invoice, even if the catalogue item is edited later.
CREATE TABLE IF NOT EXISTS purchase_catalog_items (
    id              INTEGER PRIMARY KEY,
    purchase_id     INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
    item_id         INTEGER NOT NULL REFERENCES catalog_items(id),
    item_name       TEXT NOT NULL,
    unit            TEXT NOT NULL,
    quantity_milli  INTEGER NOT NULL,
    rate_paise      INTEGER NOT NULL,
    amount_paise    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_purchase_catalog_items_purchase ON purchase_catalog_items(purchase_id);
CREATE INDEX IF NOT EXISTS idx_purchase_catalog_items_item ON purchase_catalog_items(item_id);

CREATE TABLE IF NOT EXISTS catalog_stock_movements (
    id                  INTEGER PRIMARY KEY,
    item_id             INTEGER NOT NULL REFERENCES catalog_items(id),
    purchase_id         INTEGER NOT NULL REFERENCES purchases(id),
    moved_at             TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    quantity_delta_milli INTEGER NOT NULL,
    note                 TEXT
);
CREATE INDEX IF NOT EXISTS idx_catalog_stock_item ON catalog_stock_movements(item_id, moved_at);

-- Stock lots (FIFO). One row per purchase of full cylinders: how many, at what price, and how
-- many are still on the shelf. Sales take from the oldest lot first, so profit stays correct
-- when the buying price changes. purchase_id is the "pid"; NULL for opening stock.
CREATE TABLE IF NOT EXISTS stock_lots (
    id               INTEGER PRIMARY KEY,
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    purchase_id      INTEGER REFERENCES purchases(id),
    source           TEXT NOT NULL DEFAULT 'purchase' CHECK (source IN ('purchase', 'opening', 'adjustment')),
    lot_date         TEXT NOT NULL,
    qty_in           INTEGER NOT NULL CHECK (qty_in > 0),
    qty_left         INTEGER NOT NULL CHECK (qty_left >= 0),
    unit_cost_paise  INTEGER NOT NULL DEFAULT 0,
    created_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_stock_lots_fifo ON stock_lots(cylinder_type_id, qty_left, lot_date, id);
CREATE INDEX IF NOT EXISTS idx_stock_lots_purchase ON stock_lots(purchase_id);

-- Which lots a sale (or any document) took cylinders from, and at what cost.
-- Never deleted: a cancelled sale marks its rows 'reversed' and the lots get their cylinders back.
-- lot_id is NULL only for stock that was never recorded as a lot.
CREATE TABLE IF NOT EXISTS lot_consumptions (
    id               INTEGER PRIMARY KEY,
    lot_id           INTEGER REFERENCES stock_lots(id),
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    ref_type         TEXT NOT NULL,
    ref_id           INTEGER NOT NULL,
    qty              INTEGER NOT NULL CHECK (qty > 0),
    unit_cost_paise  INTEGER NOT NULL DEFAULT 0,
    status           TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'reversed')),
    created_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_lot_consumptions_ref ON lot_consumptions(ref_type, ref_id);
CREATE INDEX IF NOT EXISTS idx_lot_consumptions_lot ON lot_consumptions(lot_id);

-- Counted changes to an ordinary item's stock that did not come from a purchase
-- (starting stock and "Adjust stock" on the Stock & Price screen). Purchases keep using
-- catalog_stock_movements. Never deleted.
CREATE TABLE IF NOT EXISTS catalog_adjustments (
    id                   INTEGER PRIMARY KEY,
    item_id              INTEGER NOT NULL REFERENCES catalog_items(id),
    moved_at             TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    kind                 TEXT NOT NULL DEFAULT 'adjustment' CHECK (kind IN ('adjustment', 'opening')),
    quantity_delta_milli INTEGER NOT NULL,
    note                 TEXT
);
CREATE INDEX IF NOT EXISTS idx_catalog_adjustments_item ON catalog_adjustments(item_id, moved_at);

-- Security deposits on cylinders, one row per event, never deleted.
--   paid = new cylinders bought (written by a purchase)   cancelled = cylinder damaged, deposit lost
--   refunded = good cylinders sent back to the supplier, deposit received
CREATE TABLE IF NOT EXISTS cylinder_deposits (
    id               INTEGER PRIMARY KEY,
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    supplier_id      INTEGER REFERENCES suppliers(id),
    kind             TEXT NOT NULL CHECK (kind IN ('paid', 'cancelled', 'refunded')),
    qty              INTEGER NOT NULL,
    amount_paise     INTEGER NOT NULL,
    purchase_id      INTEGER REFERENCES purchases(id),
    note             TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_cylinder_deposits ON cylinder_deposits(cylinder_type_id, supplier_id);

-- Physical dispatch of cylinders that were already marked damaged.
-- This is an inventory/audit record only; it does not refund or cancel deposits.
CREATE TABLE IF NOT EXISTS damaged_cylinder_dispatches (
    id            INTEGER PRIMARY KEY,
    dispatch_date TEXT NOT NULL,
    note          TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS damaged_cylinder_dispatch_items (
    id                       INTEGER PRIMARY KEY,
    dispatch_id              INTEGER NOT NULL REFERENCES damaged_cylinder_dispatches(id),
    damage_event_id          INTEGER NOT NULL REFERENCES cylinder_deposits(id),
    cylinder_type_id         INTEGER NOT NULL REFERENCES cylinder_types(id),
    supplier_id              INTEGER REFERENCES suppliers(id),
    qty                      INTEGER NOT NULL CHECK (qty > 0),
    deposit_reference_paise  INTEGER NOT NULL DEFAULT 0,
    created_at               TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    UNIQUE (dispatch_id, damage_event_id)
);
CREATE INDEX IF NOT EXISTS idx_damaged_dispatch_items_event
    ON damaged_cylinder_dispatch_items(damage_event_id);
CREATE INDEX IF NOT EXISTS idx_damaged_dispatch_items_dispatch
    ON damaged_cylinder_dispatch_items(dispatch_id);


-- v0.6: persistent customer invoice lines. Every printable detail is a snapshot.
CREATE TABLE IF NOT EXISTS sale_lines (
    id              INTEGER PRIMARY KEY,
    sale_id         INTEGER NOT NULL REFERENCES sales(id),
    line_no         INTEGER NOT NULL,
    kind            TEXT NOT NULL,
    action          TEXT,
    cylinder_type_id INTEGER REFERENCES cylinder_types(id),
    item_id         INTEGER REFERENCES catalog_items(id),
    supplier_id     INTEGER REFERENCES suppliers(id),
    description     TEXT NOT NULL,
    hsn             TEXT,
    unit            TEXT NOT NULL DEFAULT 'NOS',
    qty_milli       INTEGER NOT NULL DEFAULT 0,
    rate_paise      INTEGER NOT NULL DEFAULT 0,
    gross_paise     INTEGER NOT NULL DEFAULT 0,
    discount_paise  INTEGER NOT NULL DEFAULT 0,
    taxable_paise   INTEGER NOT NULL DEFAULT 0,
    gst_rate_bp     INTEGER,
    cgst_paise      INTEGER NOT NULL DEFAULT 0,
    sgst_paise      INTEGER NOT NULL DEFAULT 0,
    igst_paise      INTEGER NOT NULL DEFAULT 0,
    amount_paise    INTEGER NOT NULL DEFAULT 0,
    retained_paise  INTEGER NOT NULL DEFAULT 0,
    detail          TEXT
);
CREATE INDEX IF NOT EXISTS idx_sale_lines_sale ON sale_lines(sale_id, line_no);

-- Customer security deposits are independent of the agency's supplier deposits.
-- received/refunded/forfeited rows are never deleted; a cancelled invoice reverses the row.
CREATE TABLE IF NOT EXISTS customer_deposit_events (
    id              INTEGER PRIMARY KEY,
    customer_id     INTEGER NOT NULL REFERENCES customers(id),
    cylinder_type_id INTEGER NOT NULL REFERENCES cylinder_types(id),
    sale_id         INTEGER REFERENCES sales(id),
    supplier_id     INTEGER REFERENCES suppliers(id),
    kind            TEXT NOT NULL CHECK (kind IN ('received','refunded','forfeited')),
    qty             INTEGER NOT NULL DEFAULT 0,
    amount_paise    INTEGER NOT NULL DEFAULT 0,
    event_date      TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reversed')),
    note            TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_customer_deposits_customer
    ON customer_deposit_events(customer_id, cylinder_type_id, status);
CREATE INDEX IF NOT EXISTS idx_customer_deposits_sale ON customer_deposit_events(sale_id);

-- Ordinary catalogue stock movements caused by sales and sale cancellations.
CREATE TABLE IF NOT EXISTS catalog_sale_movements (
    id                   INTEGER PRIMARY KEY,
    sale_id              INTEGER NOT NULL REFERENCES sales(id),
    item_id              INTEGER NOT NULL REFERENCES catalog_items(id),
    moved_at             TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    quantity_delta_milli INTEGER NOT NULL,
    kind                 TEXT NOT NULL CHECK (kind IN ('sale','sale_cancel')),
    note                 TEXT
);
CREATE INDEX IF NOT EXISTS idx_catalog_sale_movements_item
    ON catalog_sale_movements(item_id, moved_at);